/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany._jfo_ud3.teoria;

import java.util.Scanner;

/**
 *
 * @author Campus FP
 */
public class Entradas {
    public static void main(String[] args) {
        System.out.println("Dime, producto, unidades y precio");
        Scanner sc=new Scanner(System.in);
        String producto=sc.next();
        int unidades=sc.nextInt();
        float precio=sc.nextFloat();
        System.out.println("Has comprado "+producto+" por un total de "+unidades*precio+ " €");
    }
}
