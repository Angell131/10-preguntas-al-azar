/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany._jfo_ud3.practica;

import java.util.Scanner;

/**
 *
 * @author Campus FP
 */
public class Consola {
    public static void main(String[] args) {
        int contador=0;
        Scanner sc=new Scanner(Consola.class.getResourceAsStream("preguntas.txt"));
        
        System.out.println("Primera pregunta "+sc.nextLine());
        Scanner sc1=new Scanner(System.in);
        int respuesta1=sc1.nextInt();
        if (respuesta1==28){
            System.out.println("+1");
            contador=contador+1;
        }
        else{
            System.out.println("-1");
            contador=contador-1;
        }
        System.out.println("Tu resultado actual es "+contador);
        
        System.out.println("Segunda pregunta "+sc.nextLine());
        Scanner sc2=new Scanner(System.in);
        int respuesta2=sc2.nextInt();
        if (respuesta2==6){
            System.out.println("+1");
            contador=contador+1;
        }
        else{
            System.out.println("-1");
            contador=contador-1;
        }
        System.out.println("Tu resultado actual es "+contador);
        
        System.out.println("Tercera pregunta "+sc.nextLine());
        Scanner sc3=new Scanner(System.in);
        int respuesta3=sc3.nextInt();
        if (respuesta3==3){
            System.out.println("+1");
            contador=contador+1;
        }
        else{
            System.out.println("-1");
            contador=contador-1;
        }
        System.out.println("Tu resultado actual es "+contador);
        
        System.out.println("Cuarta pregunta "+sc.nextLine());
        Scanner sc4=new Scanner(System.in);
        int respuesta4=sc4.nextInt();
        if (respuesta4==2){
            System.out.println("+1");
            contador=contador+1;
        }
        else{
            System.out.println("-1");
            contador=contador-1;
        }
        System.out.println("Tu resultado actual es "+contador);
        
        System.out.println("Quinta pregunta "+sc.nextLine());
        Scanner sc5=new Scanner(System.in);
        int respuesta5=sc5.nextInt();
        if (respuesta5==6){
            System.out.println("+1");
            contador=contador+1;
        }
        else{
            System.out.println("-1");
            contador=contador-1;
        }
        
        System.out.println("Tu resultado final es "+contador);
    }//cierra main
}
