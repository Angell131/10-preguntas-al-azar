/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany._jfo_ud3.teoria;

import java.util.Scanner;

/**
 *
 * @author Campus FP
 */
public class Cadenas {
    public static void main(String[] args) {
        //tipo primitivo char
        char letra = 'a';
        //tipo de dato cedena - Objeto
        String cadena="Hola";
        System.out.println("Dime un número entero");
        Scanner sc=new Scanner(System.in);
        int numero1=sc.nextInt();//9
        
        System.out.println("Dime un número entero");
        Scanner sc2=new Scanner(System.in);
        int numero2=sc2.nextInt();//2
        
        double resultado=(float)numero1/numero2;
        System.out.println("El resultado es "+resultado);
    }//cierra main
}//cierra clase
