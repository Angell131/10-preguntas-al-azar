/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany._jfo_ud3.teoria;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author Campus FP
 */
public class Conversiones {
    public static void main(String[] args) {
        System.out.println("Dime un precio");
        Scanner sc=new Scanner(System.in);
        float precio=0.0F;
        try {
            precio=sc.nextFloat();
        } catch (InputMismatchException e) {
            System.out.println("El decimal es con ,");
        } catch (Exception e) {
            System.out.println("Le has puesto letras");
        }
        
        System.out.println("El precio es "+precio);
    }
}
