/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany._jfo_ud3.teoria;

import java.util.Scanner;

/**
 *
 * @author Campus FP
 */
public class LeerArchivo {
    public static void main(String[] args) {
        Scanner sc=new Scanner(LeerArchivo.class.getResourceAsStream("datos.txt"));
        System.out.println("contenido "+sc.nextLine());
    }//cierra main
}//cierra clase
